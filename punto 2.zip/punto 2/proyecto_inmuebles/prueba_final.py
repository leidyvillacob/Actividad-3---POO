from clases.apto_familiar import ApartamentoFamiliar
from clases.apartaestudio import Apartaestudio

def main():
    print("Datos del apartamento familiar")
    apto = ApartamentoFamiliar(103067, 120, "Avenida Santander 45-45", 3, 2, 200000)
    apto.calcular_valor(ApartamentoFamiliar.valor_metro)
    apto.mostrar_info()
    print()

    print("Datos del apartaestudio")
    est = Apartaestudio(12354, 50, "Avenida Caracas 30-15")
    est.calcular_valor(Apartaestudio.valor_metro)
    est.mostrar_info()

if __name__ == "__main__":
    main()
from .propiedad_base import Propiedad

class Local(Propiedad):
    class Tipo:
        INTERIOR = 'INTERIOR'
        CALLE = 'CALLE'

    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str, tipo: str):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion)
        self._tipo_local = tipo

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Tipo de local = {self._tipo_local}")
from .casa_urbana import CasaUrbana

class CasaConjuntoCerrado(CasaUrbana):
    valor_metro = 2500000.0

    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str,
                 habitaciones: int, banos: int, pisos: int, admin: int, piscina: bool, deportes: bool):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, habitaciones, banos, pisos)
        self._admin = admin
        self._piscina = piscina
        self._deportes = deportes

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Administración = ${self._admin}")
        print(f"Tiene piscina? = {self._piscina}")
        print(f"Tiene campos deportivos? = {self._deportes}")
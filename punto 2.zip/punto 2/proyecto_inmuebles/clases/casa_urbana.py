from .vivienda_casa import Casa

class CasaUrbana(Casa):
    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str, habitaciones: int, banos: int, pisos: int):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, habitaciones, banos, pisos)

    def mostrar_info(self):
        super().mostrar_info()
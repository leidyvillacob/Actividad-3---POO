from .propiedad_base import Propiedad

class Vivienda(Propiedad):
    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str, habitaciones: int, banos: int):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion)
        self._cuartos = habitaciones
        self._banos = banos

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Habitaciones = {self._cuartos}")
        print(f"Baños = {self._banos}")
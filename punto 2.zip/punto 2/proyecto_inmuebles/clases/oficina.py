from .local_base import Local

class Oficina(Local):
    valor_metro = 3500000.0

    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str, tipo: str, es_gob: bool):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, tipo)
        self._es_gobierno = es_gob

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Es gubernamental = {self._es_gobierno}")
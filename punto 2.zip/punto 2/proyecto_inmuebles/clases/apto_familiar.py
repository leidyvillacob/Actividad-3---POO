from .vivienda_apto import Apartamento

class ApartamentoFamiliar(Apartamento):
    valor_metro = 5200000.0

    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str, habitaciones: int, banos: int, admin: int):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, habitaciones, banos)
        self._admin = admin

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Valor administración = ${self._admin}")
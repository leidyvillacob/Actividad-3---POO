from .tipo_vivienda import Vivienda

class Apartamento(Vivienda):
    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str, habitaciones: int, banos: int):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, habitaciones, banos)

    def mostrar_info(self):
        super().mostrar_info()
from .local_base import Local

class LocalComercial(Local):
    valor_metro = 3000000.0

    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str, tipo: str, centro: str):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, tipo)
        self._centro_comercial = centro

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Centro comercial = {self._centro_comercial}")
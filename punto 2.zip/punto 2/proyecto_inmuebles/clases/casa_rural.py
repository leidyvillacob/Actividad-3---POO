from .vivienda_casa import Casa

class CasaRural(Casa):
    valor_metro = 1500000.0

    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str,
                 habitaciones: int, banos: int, pisos: int, distancia_cabecera: int, altitud: int):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, habitaciones, banos, pisos)
        self._distancia = distancia_cabecera
        self._altitud = altitud

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Distancia a cabecera municipal = {self._distancia} km")
        print(f"Altitud sobre nivel del mar = {self._altitud} m")
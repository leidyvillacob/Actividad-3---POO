from .vivienda_apto import Apartamento

class Apartaestudio(Apartamento):
    valor_metro = 1360000.0

    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, 1, 1)

    def mostrar_info(self):
        super().mostrar_info()
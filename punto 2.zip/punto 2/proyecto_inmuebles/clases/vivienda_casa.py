from .tipo_vivienda import Vivienda

class Casa(Vivienda):
    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str, habitaciones: int, banos: int, pisos: int):
        super().__init__(id_propiedad, metros_cuadrados, ubicacion, habitaciones, banos)
        self._niveles = pisos

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Pisos = {self._niveles}")
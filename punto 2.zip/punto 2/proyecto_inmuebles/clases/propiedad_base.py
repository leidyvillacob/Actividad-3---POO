class Propiedad:
    def __init__(self, id_propiedad: int, metros_cuadrados: int, ubicacion: str):
        self._id = id_propiedad
        self._metros = metros_cuadrados
        self._ubicacion = ubicacion
        self._valor_final = 0.0

    def calcular_valor(self, precio_metro: float) -> float:
        self._valor_final = self._metros * precio_metro
        return self._valor_final

    def mostrar_info(self):
        print(f"ID Propiedad = {self._id}")
        print(f"Área = {self._metros}")
        print(f"Ubicación = {self._ubicacion}")
        print(f"Valor de venta = ${self._valor_final:.2f}")